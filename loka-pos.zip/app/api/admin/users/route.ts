import { NextResponse } from "next/server";
import { requireAdminApi } from "@/lib/admin-api-auth";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

type AuthUser = {
  id: string;
  email?: string | null;
  created_at?: string;
  last_sign_in_at?: string | null;
  user_metadata?: {
    full_name?: string;
    role?: string;
  } | null;
  app_metadata?: {
    role?: string;
  } | null;
};

type ListUsersResponse = {
  data?: {
    users?: AuthUser[];
  };
  error?: {
    message?: string;
  } | null;
};

type ProfileRow = {
  id: string;
  role: string | null;
  full_name: string | null;
};

function pickNonEmpty(...values: Array<string | null | undefined>) {
  for (const value of values) {
    const trimmed = String(value || "").trim();
    if (trimmed) return trimmed;
  }
  return "";
}

function emailPrefix(email: string) {
  const localPart = String(email || "").split("@")[0] || "";
  return localPart.trim();
}

function normalizeRole(value: string | null | undefined) {
  const role = String(value || "").toLowerCase();
  if (role === "admin" || role === "cashier" || role === "customer") return role;
  return "unknown";
}

export async function GET(req: Request) {
  const auth = await requireAdminApi();
  if (!auth.ok) return auth.response;

  const { searchParams } = new URL(req.url);
  const q = String(searchParams.get("q") || "").trim().toLowerCase();
  const roleFilter = String(searchParams.get("role") || "all").toLowerCase();

  try {
    const supabase = createSupabaseAdminClient();
    const users: AuthUser[] = [];
    let page = 1;
    const perPage = 200;

    while (page <= 10) {
      const result = (await supabase.auth.admin.listUsers({ page, perPage })) as ListUsersResponse;
      if (result.error?.message) {
        return NextResponse.json({ error: result.error.message }, { status: 500 });
      }

      const batch = result.data?.users || [];
      users.push(...batch);
      if (batch.length < perPage) break;
      page += 1;
    }

    const userIds = users.map(user => user.id);
    const emails = users.map(user => String(user.email || "").trim().toLowerCase()).filter(Boolean);
    const profileRoleMap = new Map<string, string>();
    const profileNameMap = new Map<string, string>();
    const requestNameMap = new Map<string, string>();

    if (userIds.length > 0) {
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id,role,full_name")
        .in("id", userIds);

      if (profilesError) {
        return NextResponse.json({ error: profilesError.message }, { status: 500 });
      }

      for (const row of (profiles || []) as ProfileRow[]) {
        profileRoleMap.set(row.id, normalizeRole(row.role));
        profileNameMap.set(row.id, String(row.full_name || "").trim());
      }
    }

    if (emails.length > 0) {
      const { data: signupRequests } = await supabase
        .from("signup_requests")
        .select("email,full_name,requested_at")
        .in("email", emails)
        .order("requested_at", { ascending: false });

      for (const row of signupRequests || []) {
        const email = String(row.email || "").trim().toLowerCase();
        const fullName = String(row.full_name || "").trim();
        if (!email || !fullName || requestNameMap.has(email)) continue;
        requestNameMap.set(email, fullName);
      }
    }

    const mapped = users
      .map(user => {
        const email = user.email || "";
        const fullName = pickNonEmpty(
          user.user_metadata?.full_name,
          // Support users created with `name` key instead of `full_name`.
          (user.user_metadata as { name?: string } | null)?.name,
          profileNameMap.get(user.id),
          requestNameMap.get(email.toLowerCase()),
          emailPrefix(email)
        );
        const role = normalizeRole(
          profileRoleMap.get(user.id) || user.app_metadata?.role || user.user_metadata?.role
        );

        return {
          id: user.id,
          email,
          full_name: fullName,
          role,
          created_at: user.created_at || null,
          last_sign_in_at: user.last_sign_in_at || null,
        };
      })
      .filter(user => {
        const matchRole = roleFilter === "all" || user.role === roleFilter;
        const matchQuery =
          !q ||
          user.email.toLowerCase().includes(q) ||
          user.full_name.toLowerCase().includes(q) ||
          user.role.toLowerCase().includes(q);
        return matchRole && matchQuery;
      })
      .sort((a, b) => {
        const aTime = new Date(a.created_at || 0).getTime();
        const bTime = new Date(b.created_at || 0).getTime();
        return bTime - aTime;
      });

    const counts = mapped.reduce(
      (acc, user) => {
        acc.total += 1;
        if (user.role === "admin") acc.admin += 1;
        if (user.role === "cashier") acc.cashier += 1;
        if (user.role === "customer") acc.customer += 1;
        if (user.role === "unknown") acc.unknown += 1;
        return acc;
      },
      { total: 0, admin: 0, cashier: 0, customer: 0, unknown: 0 }
    );

    return NextResponse.json({ users: mapped, counts });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to load active users";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

// ================= UPDATE USER (name, role) =================
export async function PATCH(req: Request) {
  const auth = await requireAdminApi();
  if (!auth.ok) return auth.response;

  try {
    const body = await req.json();
    const userId = String(body?.user_id || "").trim();
    if (!userId) return NextResponse.json({ error: "user_id required" }, { status: 400 });

    const supabase = createSupabaseAdminClient();
    const updates: Record<string, unknown> = {};

    if (body.full_name !== undefined) {
      const name = String(body.full_name || "").trim();
      if (name) {
        // Update profile table
        await supabase.from("profiles").upsert({ id: userId, full_name: name }, { onConflict: "id" });
        // Update auth user metadata
        await supabase.auth.admin.updateUserById(userId, { user_metadata: { full_name: name } });
        updates.full_name = name;
      }
    }

    if (body.role !== undefined) {
      const role = String(body.role || "").toLowerCase();
      if (["admin", "cashier", "customer"].includes(role)) {
        await supabase.from("profiles").upsert({ id: userId, role }, { onConflict: "id" });
        await supabase.auth.admin.updateUserById(userId, { app_metadata: { role } });
        updates.role = role;
      }
    }

    if (body.phone !== undefined) {
      const phone = String(body.phone || "").trim();
      // Store phone in user metadata
      const { data: currentUser } = await supabase.auth.admin.getUserById(userId);
      const currentMeta = currentUser?.user?.user_metadata || {};
      await supabase.auth.admin.updateUserById(userId, { user_metadata: { ...currentMeta, phone } });
      updates.phone = phone;
    }

    return NextResponse.json({ success: true, updates });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to update user";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
